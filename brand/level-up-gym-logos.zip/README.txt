LEVEL UP · PERSONALISED FITNESS STUDIO · GYM LOGOS (SET H)
=============================================================

Twelve logo options. Each folder holds the complete kit for one of them:

H1 Kettlebell Rise (Archivo Expanded Black Italic): 12 SVG + 14 PNG, in H1-kettlebell-rise/
H2 Lifter U (Unbounded ExtraBold): 12 SVG + 14 PNG, in H2-lifter-u/
H3 Plate Levels (Big Shoulders Display Black): 12 SVG + 14 PNG, in H3-plate-levels/
H4 Bumper Plate (Archivo Expanded Black): 12 SVG + 14 PNG, in H4-bumper-plate/
H5 Varsity Crest (Graduate): 12 SVG + 14 PNG, in H5-varsity-crest/
H6 Progress Ring (Anton): 12 SVG + 14 PNG, in H6-progress-ring/
H7 Power Dumbbell (Russo One): 12 SVG + 14 PNG, in H7-power-dumbbell/
H8 Level Bar (Sora ExtraBold): 12 SVG + 14 PNG, in H8-level-bar/
H9 Crossed Dumbbells (Oswald Bold): 12 SVG + 14 PNG, in H9-crossed-dumbbells/
H10 Heart & Iron (Kanit ExtraBold Italic): 12 SVG + 14 PNG, in H10-heart-iron/
H11 Slam Ball (Montserrat Black Italic): 12 SVG + 14 PNG, in H11-slam-ball/
H12 Box Jump (Teko Bold): 12 SVG + 14 PNG, in H12-box-jump/

WHICH FILE FOR WHICH JOB
- Website header / navigation bar ....... svg/*-horizontal-no-tagline.svg (…-reversed.svg on dark headers)
- Website footer, documents, email ....... svg/*-horizontal.svg (with the tagline)
- Splash screen, posters, social posts ... svg/*-stacked.svg or *-stacked-reversed.svg
- Mobile app launcher icon ............... png/*-app-icon-1024.png (the stores apply their own corner mask)
- Android / PWA icons .................... png/*-app-icon-512.png and *-app-icon-192.png
- iOS home screen (web) .................. png/*-apple-touch-icon-180.png
- Browser tab favicon .................... svg/*-favicon.svg, png/*-favicon-32.png and *-favicon-16.png
- One-colour print, embroidery, stamps ... svg/*-mono-black.svg / *-mono-white.svg
- Profile pictures, stickers ............. svg/*-icon.svg

SVG files are vectors: they scale to any size without losing quality. Lettering is
converted to shapes, so no fonts need installing. Backgrounds are transparent except
the app icon and favicon, which carry their own solid background.

COLOURS (matching the Level Up app theme)
- Brand red ..... #E1140A  RGB 225 20 10
- Hero black .... #0F0F0F  RGB 15 15 15
- Off-white ..... #F5F5F2  RGB 245 245 242
- White ......... #FFFFFF

TYPEFACES (all free for commercial use, SIL Open Font License)
- Wordmarks: H1 Archivo Expanded Black Italic, H2 Unbounded ExtraBold, H3 Big Shoulders Display Black, H4 Archivo Expanded Black, H5 Graduate, H6 Anton, H7 Russo One, H8 Sora ExtraBold, H9 Oswald Bold, H10 Kanit ExtraBold Italic, H11 Montserrat Black Italic, H12 Teko Bold
- Tagline: Montserrat SemiBold

USAGE
- Clear space: keep empty space around the logo at least the height of the letter E.
- Smallest size: icon 16 px; full horizontal logo 120 px wide (drop the tagline below 200 px).
- Don't stretch, rotate, recolour outside the palette, or add shadows and outlines.
