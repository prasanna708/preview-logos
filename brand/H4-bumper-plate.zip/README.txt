LEVEL UP · PERSONALISED FITNESS STUDIO · GYM LOGOS (SET H)
=============================================================

Six logo options. Each folder holds the complete kit for one of them:

H1 Kettlebell Rise (Archivo Expanded Black Italic): 12 SVG + 14 PNG
H2 Lifter U (Unbounded ExtraBold): 12 SVG + 14 PNG
H3 Plate Levels (Big Shoulders Display Black): 12 SVG + 14 PNG
H4 Bumper Plate (Archivo Expanded Black): 12 SVG + 14 PNG
H5 Varsity Crest (Graduate): 12 SVG + 14 PNG
H6 Progress Ring (Anton): 12 SVG + 14 PNG

WHICH FILE FOR WHICH JOB
- Website header / navigation bar ....... svg/*-horizontal-no-tagline.svg (…-reversed.svg on dark headers)
- Website footer, documents, email ....... svg/*-horizontal.svg (with the tagline)
- Splash screen, posters, social posts ... svg/*-stacked.svg or *-stacked-reversed.svg
- Mobile app launcher icon ............... png/*-app-icon-1024.png (the stores apply their own corner mask)
- Android / PWA icons .................... png/*-app-icon-512.png and *-app-icon-192.png
- iOS home screen (web) .................. png/*-apple-touch-icon-180.png
- Browser tab favicon .................... svg/*-favicon.svg, png/*-favicon-32.png and *-favicon-16.png
- One-colour print, embroidery, stamps ... svg/*-mono-black.svg / *-mono-white.svg
- Profile pictures, stickers ............. svg/*-icon.svg

SVG files are vectors: they scale to any size without losing quality. Lettering is
converted to shapes, so no fonts need installing. Backgrounds are transparent except
the app icon and favicon, which carry their own solid background.

COLOURS (matching the Level Up app theme)
- Brand red ..... #E1140A  RGB 225 20 10
- Hero black .... #0F0F0F  RGB 15 15 15
- Off-white ..... #F5F5F2  RGB 245 245 242
- White ......... #FFFFFF

TYPEFACES (all free for commercial use, SIL Open Font License)
- Wordmarks: Archivo Expanded Black (H1, H4), Unbounded ExtraBold (H2),
  Big Shoulders Display Black (H3), Graduate (H5), Anton (H6)
- Tagline: Montserrat SemiBold

USAGE
- Clear space: keep empty space around the logo at least the height of the letter E.
- Smallest size: icon 16 px; full horizontal logo 120 px wide (drop the tagline below 200 px).
- Don't stretch, rotate, recolour outside the palette, or add shadows and outlines.
